
<?php $__env->startSection('titlePage', 'Configuración'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main h-10/12 w-6/6 lg:w-4/6 p-5">
        <div class="settingsContainer bg-gray-100 w-full p-6 rounded-lg">
            <h1 class="text-2xl">Configuración</h1>
            <?php if(session('success')): ?>
                <script>
                    const mylocalstorage = window.localStorage;
                    mylocalstorage.setItem('successLaravel', "<?php echo e(session('success')); ?>");
                </script> 
            <?php elseif(session('error')): ?>
                <script>
                    console.log("<?php echo e(session('error')); ?>");
                    mylocalstorage = window.localStorage;
                    mylocalstorage.setItem('laravelError', "<?php echo e(session('error')); ?>");
                </script>
            <?php endif; ?>
            <form enctype="multipart/form-data" action="<?php echo e(route('user.updateDetails')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="relative flex w-full flex-col justify-center items-center p-5">
                <!-- Imagen de perfil -->
                    <label for="profile-image" class="cursor-pointer">
                        <img id="profile-preview" 
                            class="w-32 h-32 rounded-full object-cover object-top border-2 border-gray-300 hover:opacity-80" 
                            src="<?php echo e(isset(auth()->user()->image) ? Storage::url(auth()->user()->image) : '/img/default.png'); ?>" 
                            alt="Foto de perfil">
                    </label>
                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="mt-3 block text-red-500 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <!-- Input oculto para subir la imagen -->
                    <input type="file" id="profile-image" name="image" accept="image/*" class="hidden">
                </div>
                <!-- Usuario y Email -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-3 mt-4">
                    <div>
                        <label class="flex justify-between text-gray-700 mb-2" for="userSettings">
                        Usuario
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </label>

                        <input type="text" id="userSettings" name="name" class="bg-white p-2 mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500" value="<?php echo e(auth()->user()->name); ?>">
                    </div>
                    <div>
                        <label class="flex justify-between text-gray-700 mb-2" for="emailSettings">
                        Email
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </label>
                        <input type="email" id="emailSettings" name="email" class="bg-white p-2 mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500" value="<?php echo e(auth()->user()->email); ?>">
                    </div>
                </div>

                <div class="flex gap-4">
                    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md">
                        Confirmar
                    </button>
                </div>
            </form>
            <div class="containerChangePassword py-5">
                <form action="<?php echo e(route('user.updatePassword')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <!-- Contraseñas -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-3 mt-8">
                        <div>
                            <label class="flex justify-between text-gray-700 mb-2" for="newPassword">
                            Nueva contraseña
                            <?php $__errorArgs = ['newPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </label>
                            <input type="password" id="newPassword" name="newPassword"
                                    class="bg-white p-2 mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        </div>
                        <div>
                            <label class="flex justify-between text-gray-700 mb-2" for="confirmNewPassword">
                            Repetir contraseña
                            <?php $__errorArgs = ['confirmNewPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </label>
                            <input type="password" id="confirmNewPassword" name="confirmNewPassword"
                                    class="bg-white p-2 mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        </div>
                    </div>
                    <div class="flex gap-4">
                        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md">
                            Cambiar contraseña
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_partials.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\logan\Desktop\prueba\Coordify\resources\views/app/settings.blade.php ENDPATH**/ ?>