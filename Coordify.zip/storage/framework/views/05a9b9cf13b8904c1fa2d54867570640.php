
<?php $__env->startSection('titlePage', 'Agregar administrador'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main w-4/6 h-11/12 flex flex-col justify-center gap-5">
    <section>
  <div
    class="flex bg-white items-center justify-center px-4 py-10 sm:px-6 sm:py-16 lg:px-8 lg:py-8"
  >
    <div class="xl:mx-auto xl:w-full shadow-md p-4 xl:max-w-sm 2xl:max-w-md">
      <div class="mb-2 flex justify-center"></div>
      <h2 class="text-center text-2xl font-bold leading-tight text-black">
        Agregar nuevo administrador
      </h2>
      <form class="mt-8" method="POST" action="<?php echo e(route('events.newadmin')); ?>">
        <?php echo csrf_field(); ?>
        <div class="space-y-5">
          <div>
            <label class="text-base font-medium text-gray-900">
              Nombre
            </label>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="mt-2">
              <input
                placeholder="Carlos"
                type="text"
                class="flex h-10 w-full rounded-md border border-gray-300 bg-transparent px-3 py-2 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:ring-offset-1 disabled:cursor-not-allowed disabled:opacity-50"
                name="name"
                />
            </div>
          </div>
        <div class="space-y-5">
          <div>
            <label class="text-base font-medium text-gray-900">
              Correo
            </label>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="mt-2">
              <input
                placeholder="example@example.com"
                type="email"
                class="flex h-10 w-full rounded-md border border-gray-300 bg-transparent px-3 py-2 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:ring-offset-1 disabled:cursor-not-allowed disabled:opacity-50"
                name="email"
                />
            </div>
          </div>
          <div>
            <button
              class="inline-flex w-full items-center justify-center rounded-md bg-black px-3.5 py-2.5 font-semibold leading-7 text-white hover:bg-black/80"
              type="submit"
            >
              Agregar
            </button>
          </div>
        </div>
      </form>
      </div>
    </div>
  </div>
</section>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_partials.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\logan\Desktop\prueba\Coordify\resources\views/app/newadmin.blade.php ENDPATH**/ ?>