<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coordify | <?php echo $__env->yieldContent('titlePage'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>
    <div class="flex flex-col items-center justify-center h-[100vh]">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html><?php /**PATH C:\Users\logan\Desktop\prueba\Coordify\resources\views/_partials/layout-login.blade.php ENDPATH**/ ?>