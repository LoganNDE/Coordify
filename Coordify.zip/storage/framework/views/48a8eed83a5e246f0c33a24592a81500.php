<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coordify | <?php echo $__env->yieldContent('titlePage'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>
    <?php if(auth()->check()): ?>
        <script>
                const mylocalstorage = window.localStorage;
                mylocalstorage.setItem('csrf_token', "<?php echo e(csrf_token()); ?>");
        </script>    
    <?php endif; ?>
    <div class="flex flex-col items-center justify-center w-full lg:max-h-[90%] lg:h-[90%]">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <div class="w-full flex justify-center sticky bottom-0 lg:bottom-10">
        <nav class="navContainer px-10 lg:mt-4 rounded-3xl bg-gray-100 lg:min-h-18 min-h-16">
            <div class="flex w-full justify-center gap-8 md:gap-10 lg:gap-15 items-center h-full">
            <a href="<?php echo e(route('events.index')); ?>"><img src="<?php echo e(asset('img/home.svg')); ?>" class="lg:w-10 lg:h-10 min-w-8 h-8" alt="home"></a>
            <!-- Por que tengo que poner min-w para que me funcione -->
            <a href=""><img src="<?php echo e(asset('img/menu.svg')); ?>" class="lg:w-10 lg:h-10 min-w-8 h-8" alt=""></a>
            <a href=""><img src="<?php echo e(asset('img/history.svg')); ?>" class="lg:w-10 lg:h-10 min-w-8 h-8" alt=""></a>
            <a href="<?php echo e(route('events.settings')); ?>"><img src="<?php echo e(asset('img/setting.svg')); ?>" class="lg:w-10 lg:h-10 min-w-8 h-8" alt="settings"></a>
            <a href="<?php echo e(route('logout')); ?>"><img src="<?php echo e(asset('img/exit.svg')); ?>" class="lg:w-10 lg:h-10 min-w-8 h-8" alt="logout" id="logout"></a>
        </nav>
    </div>
</body>
</html><?php /**PATH C:\Users\logan\Desktop\prueba\Coordify\resources\views/_partials/layout.blade.php ENDPATH**/ ?>