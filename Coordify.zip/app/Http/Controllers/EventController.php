<?php

namespace App\Http\Controllers;

use App\Models\Administrator;
use App\Models\Event;
use App\Models\EventArchive;
use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

use function Laravel\Prompts\error;

class EventController extends Controller
{
    /**
     * Display a listing of the resource.
     */

     public function __construct()
     {
        $this->middleware('auth:web,admin')->except(['login']);
     }

    public function index()
    {
        $mainAdmin_id = isset(auth()->user()->user_id) ? auth()->user()->user_id : auth()->user()->id;
        $events = User::findOrFail($mainAdmin_id)->events;
        $mainAdmin = User::findOrFail($mainAdmin_id);
        $administrators = Administrator::where('user_id',$mainAdmin_id)->get();
        $eventsArchive = count(EventArchive::get());
        return view('app.index', compact('events', 'eventsArchive', 'administrators', 'mainAdmin'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
            return view('app.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'province' => 'required|string|max:255',
            'address' => 'required|string|max:255',
            'startDate' => 'required|date',
            'startTime' => 'required|date_format:H:i',
            'endDate' => 'nullable|date',
            'endTime' => 'required|date_format:H:i',
            'paymentType' => 'required|in:free,paid',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'description' => 'nullable|string',
            'user_id' =>    'required'
        ]);

        Event::create($validatedData);
        //Mail::to(auth()->user()->email)->send(new PostMail());
        return redirect()->route('events.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $event = Event::findOrFail($id);
        return view('app.update', compact('event'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        // Validación de los datos
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'province' => 'required|string|max:255',
            'address' => 'required|string|max:255',
            'startDate' => 'required|date',
            'startTime' => 'required|date_format:H:i:s',
            'endDate' => 'nullable|date',
            'endTime' => 'required |date_format:H:i:s',
            'paymentType' => 'required|in:free,paid',
            'description' => 'nullable|string',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        // Buscar el evento por su ID
        $event = Event::findOrFail($id);  // Usa findOrFail para obtener el evento o devolver un error 404 si no se encuentra

        // Actualizar el evento con los datos validados
        $event->update($validatedData);
        return redirect()->route('events.index')->with('success', 'Evento actualizado con éxito');

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        Event::findOrFail($id)->delete();
        return redirect()->route('events.index');
    }



    public function archive(string $id){
        $event = Event::findOrFail($id);
        EventArchive::create($event->toArray());
        $event->delete();
        return redirect()->route('events.index');
    }


    public function importEvent(Request $request)
    {   


        //VALIDAR REQUEST, COMPROBAR SI HACE EL RESPONSE EN JSON EN CASO QUE LA VALIDACION SEA ERRONEA
        

        
        try{
            dd($request->file);
            $event = new Event();
            while ( ($line= fgetcsv($request->input('file'), 1000, ",")) !==FALSE )
            {
                $event->name = $line[0];
                $event->description = $line[1];
                $event->province = $line[2];
                $event->adress = $line[3];
                $event->startDate = $line[4];
                $event->startTime = $line[5];
                $event->endDate = $line[6];
                $event->endTime = $line[7];
                $event->paymentType = $line[8];
                $event->image = $line[9];
                $event->user_id = 1;
            }
            $event->save();
        }catch(Exception $e){
            return response()->json([
                'status' => 'error'
            ]);
        }

        return response()->json([
            'status' => 'ok',
            'response' => 'archivo subido correctamente',
        ]);
    }
}
