<div>
    <h1>Este es mi primer mail mandado desde laravel</h1>
</div>